Introduction
============
First off, thanks for purchasing Bootstrap for Shopify! I really appreciate your support, and pledge to do all I can to make sure you get maximum value from the framework.

Whether you're looking to develop a theme for sale, for a specific client, or for yourself, Bootstrap for Shopify has done a lot of the initial work for you - without making any choices that might constrain your design.

> For the sake of brevity, "Bootstrap for Shopify" is often condensed to "BS4SF" or just "the framework" throughout this document.

This document serves as a short introduction to the framework, and gives you a heads up on how things work. If you have prior experience with Bootstrap and Shopify theme building, a lot of this stuff will be very familiar. If you're lacking that experience, don't stress! The first couple of sections provide an introduction to building with Bootstrap and Shopify, and point you to some useful resources if you'd like to learn more.

Of course, if you run into any truly thorny problems putting it all together, please feel free to email me at gavin@bootstrapforshopify.com.

Thanks again, and happy building!

Gavin


Building with Bootstrap
=======================
> If you're familiar with the Bootstrap framework, you can skip this section.

If you've taken the time to download and read this guide, you've probably heard of the [Bootstrap framework](http://twitter.github.io/bootstrap/). Originally developed in-house at Twitter to provide internal web projects with a simple and usable interface, it's now the most widely-used front-end framework in the world. (If this was a Wikipedia article, I'm sure someone would slap a [citation needed] on the end of that last sentence, but just trust me - [heaps](http://discovery.com/) [of](http://latenightwithjimmyfallon.com/) [folks](http://lifehacker.com.au/) [use](http://www.fender.com/) [it](https://www.varnish-software.com/).)

Why is it so popular? Well, mostly because it provides a number of really common web UI components - grids, buttons, navigation bars, dropdowns, alerts, popup modals, et cetera - and does this cross-browser out of the box. More recent versions of Bootstrap have also included styles that help making responsive websites. Put simply, if you're looking to get a site up and running quickly, Bootstrap makes it very easy to produce something usable in a short amount of time.

> Heads up! In August 2013, version 3.0.0 of Bootstrap was released, superseding version 2.3.2. There are quite a few significant differences between the two versions (for a full account, [see the official site](http://getbootstrap.com/getting-started/#migration). Bootstrap for Shopify ships with support for both versions, and while the walkthroughs in the later part of this guide deal primarily with Bootstrap 3, the final walkthrough steps you through the differences between the versions and will make sure you can get Bootstrap 2 themes up and running if that's what you need.

There's a wealth of information out there on how to get started building Bootstrap sites, so I won't try to recreate them here (besides, I'm kind of assuming that most readers will probably have a working knowledge of the framework anyway). If you are just starting out with Bootstrap, here are the top resources I'd recommend:

### Learning Bootstrap
- [Official Bootstrap Site](http://getbootstrap.com/): just reading through the documentation and examples on the official Bootstrap site can get you 90% of the way to Bootstrap proficiency! It really is pretty straightforward.
- [Bootstrap Introduction](http://www.adobe.com/devnet/html5/articles/twitter-bootstrap.html): Holly Schinsky over at Adobe's DevNet gives a good introduction to the framework.
- [Bootstrap on Github](https://github.com/twitter/bootstrap): reading through the original code for Bootstrap will give you a better understanding of how the framework has been assembled.
- [Migrating to Bootstrap 3](http://bootply.com/bootstrap-3-migration-guide): a detailed guide on what's changed between Bootstrap 2 and 3, along with an automated conversion tool

### Tools & Resources
- [Jetstrap](https://jetstrap.com/): A really nifty drag-and-drop interface builder for Bootstrap.
- [Bootswatch](http://bootswatch.com/): some simple, free themes for Bootstrap.
- [Wrap Boostrap](https://wrapbootstrap.com/): solid, low-cost Bootstrap themes.
- [Love Bootstrap](http://lovebootstrap.com/): get inspired by some of the great design achievable with Bootstrap.

### Asking Questions
- [Stack Overflow](http://stackoverflow.com/questions/tagged/twitter-bootstrap): Another great place to ask questions about Bootstrap - in fact, you'll probably find that your question has already been answered here!
- [Github Issues](https://github.com/twitter/bootstrap/issues): If you're experiencing an issue, check to see if anyone else has reported in on GitHub.
- [Email Me](mailto:gavin@bootstrapforshopify.com): If you can't find an answer to your question through the above resources or Google, get in touch!


Building Shopify Themes
=======================
> If you're familiar with building Shopify themes, you can skip this section.

Shopify's one of a number of solutions for people setting up an online store. It's also (in my opinion) one of the easiest for people without too much technical nous to use, providing a simple interface for inventory management, content generation, and payment integration. One of the things that make it so appealing is the large marketplace for Shopify themes (free and paid) available to store owners. Custom-made and customisable themes give Shopify stores their own look and feel.

Creating new Shopify themes isn't too different from building regular web sites - you're still dealing with HTML, CSS and Javascript. The "new" thing to learn when building on Shopify for the first time is the Liquid templating language, and how it works in the context of Shopify themes.

Like any number of templating languages out there, Liquid templates allow authors to display dynamic content on their pages, as well as use conditional logic (like if...else blocks). As with the Bootstrap framework, there are a huge number of resources out there to help you understand how Shopify templates and themes are structured, and how to start building your own. I won't try to reinvent the wheel.

### Shopify Theme Resources
- Tetsuro Takara's [Shopify Theme from Scratch](http://www.tetchi.ca/shopify-theme-from-scratch/): A great place to get started learning how to build Shopify Themes.
- Keir Whitaker's [Shopify for Designers](http://shopify-for-designers.keirwhitaker.com/) is a super great resource giving clear explanations for Shopify concepts.
- The Shopify Wiki [Tutorial Page](http://wiki.shopify.com/Tutorials): Contains a number of more advanced tutorials on various aspects of theme building (some are slightly dated).
- Mark Dunkley's [Shopify Cheat Sheet](http://cheat.markdunkley.com/): a comprehensive list of tags, modifiers and filters to use when building Shopify-specific Liquid templates.
- The [Shopify Design Forum](http://ecommerce.shopify.com/c/ecommerce-design): if all else fails, head here and see if your question has been answered already. If not, there are plenty of friendly folk willing to help you out.
- [Email Me](mailto:gavin@bootstrapforshopify.com): If the above resources aren't providing the help you need, I'm more than happy to help you out. Shoot me an email and I'll try to get back to you as soon as possible!


Bootstrap for Shopify
==========================================

Why Bootstrap for Shopify?
--------------------------
Bootstrap for Shopify takes the benefits of the Bootstrap framework (a widely-used, standards-based, flexible CSS/JS framework) and makes them available immediately in prebuilt Shopify templates. These templates not only provide a sensible, Bootstrap-based default, but also implement a number of useful Shopify features, work around some interesting Shopify quirks, and make it easy to customise and extend a theme. As anyone who's built a Shopify theme will tell you, this is a massive time saving - a designer or developer can get started on implementing their own vision straight away instead of battling a myriad of Shopify template details.

One of the criticisms that's often levelled at Bootstrap is that sites using it suffer from "the Bootstrap Look" - that is, because it's so popular, sites that use the framework without much customisation start looking very generic. My first response to this is that design nerds often care about this waaay more than users (who mostly care about the easiest way to achieve their goals, not necessarily the prettiest). However, it is often important to give a Shopify store its own personality, both for your own sense of style and in the case of paid client work, to ensure they don't feel like your deliverables are just "off the shelf".

Fortunately, the folks who contend that Bootstrap themes can't be given a sense of their own style are just dead wrong - look no further than [Love Bootstrap](http://www.lovebootstrap.com) to see just how far the framework can be taken. The best thing is, with Bootstrap for Shopify, you can take the work that others have put into building awesome Bootstrap themes and use them straight away on Shopify. This opens up many more opportunities for designers and store owners, as Bootstrap themes are more numerous and varied than store themes in the Shopify Theme Store (and are almost always much cheaper, as well).

Choosing a Bootstrap Version
----------------------------
As highlighted in the *'Building with Bootstrap'* section, there are currently two major versions of Bootstrap in use: 2.3.2 and 3.0.2. Version 3 of Bootstrap (released in August 2013) is, as the version numbers would suggest, a major change for the framework and it introduces a lot of new features while dropping support for others. Some of the most significant changes from version 2 to version 3 are a paradigm shift to mobile-first development, more of a 'flat' aesthetic, and the dropping of support for older browsers.

Bootstrap for Shopify ships with fully-implemented themes for both versions of Bootstrap, and will continue to deliver updates and support for both. So, if you need to support older versions of Internet Explorer, or have an existing Bootstrap 2 theme you'd like to work with, Bootstrap for Shopify will play nice.


Walkthrough: Getting Started
==========================================
> In this walkthrough, we'll see how to get a new site set up with the framework, and step through the layout and contents of the default theme. By the end of it, you should be ready to start customising themes and seeing changes live of your store.

Before we get started, a disclaimer: I've tried my best to make this walkthrough as clear and concise as possible - but if you're finding something to be frustrating, not working, or downright incomprehensible, that'll most likely be my fault, not yours! If this does happen, please let me know - I'll do my best to help you out (and it means I can then update the guide for others).

### 1. Before We Begin
This walkthrough assumes that you have [set up a store on Shopify](http://www.shopify.com/?ref=bootstrap-for-shopify), and [purchased a licence](http://bootstrapforshopify.com/) for the Bootstrap for Shopify framework. If you haven't done either of those things, do so now! I'll wait.

> If you're new to Shopify development and just want to try out Bootstrap for Shopify for free, you can! Just sign up for a new free trial store using [this link](http://www.shopify.com/?ref=bootstrap-for-shopify) (it's my affiliate link), and then get in touch with me at [gavin@bootstrapforshopify.com](mailto:gavin@bootstrapforshopify.com). You'll get a free copy of the framework that you're allowed to use on that store only.

If you're unfamiliar with the Shopify, now would be a good time to read the excellent official [Shopify Manual](http://docs.shopify.com/manual).

### 2. Upload Default Theme
Now that you've got a store and the framework, let's upload the default theme to your store. Start by finding the ZIP file you downloaded when you purchased the framework (or the ZIP file emailed to you, for those of you with Affiliate licences). Once unzipped, you should see a number of files, including one named `bootstrap-2.zip` and one named `bootstrap-3.zip`. These are the default themes we can upload directly to our Shopify store.

Log in to your Shopify administration panel (the URL will be something like `https://yourstore.myshopify.com/admin`), then click "Themes". Click the "Upload a theme" button, and select either `bootstrap-2.zip` (if you'd like to use the Bootstrap 2.3.2 version of the product) or `bootstrap-3.zip` (for the Bootstrap 3 version).

Once the upload has finished, you should see a new theme named `bootstrap-2` in your unpublished themes list. To go live with the new theme, just click "Publish" - and you're done! You can now start customising the theme by clicking "Template Editor" and updating the files found there.

If you'd like an easier way to customise your themes (and you're using a Mac), check out the [Shopify Desktop Theme Editor](http://apps.shopify.com/desktop-theme-editor), which allows you to edit theme files from your favourite text editing program and automatically update the theme live on your store.