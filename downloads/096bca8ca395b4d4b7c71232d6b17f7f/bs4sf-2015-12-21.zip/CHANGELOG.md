Bootstrap for Shopify Changelog
===============================

## Unreleased
No unreleased changes.

## V1.10.1 (December 21, 2015)

- Add support for variant deep linking
- Add support for selecting variants via thumbnails

## V1.10.0 (December 1, 2015)

- Updated Bootstrap 3 Theme to Bootstrap 3.3.6

## V1.9.0 (June 22, 2015)

- Updated Bootstrap 3 Theme to Bootstrap 3.3.5
- Fix bug with carousel slider dots
- Automatically start carousel if present

## V1.8.0 (March 21, 2015)

- Updated Bootstrap 3 Theme to Bootstrap 3.3.4

## V1.7.2 (January 19, 2015)

- Updated Bootstrap 3 Theme to Bootstrap 3.3.2

## V1.7.1 (November 18, 2014)

- Updated Bootstrap 3 Theme to Bootstrap 3.3.1

## V1.7.0 (October 30, 2014)

- Updated Bootstrap 3 Theme to Bootstrap 3.3.0
- Minor accessibility updates

## V1.6.0 (August 4, 2014)

- Updated Bootstrap 3 Theme to Bootstrap 3.2.0
- Minor improvements and bugfixes

## V1.5.0 (March 11, 2014)

- Updated Bootstrap 3 Theme to Bootstrap 3.1.1
- Updated checkout.css.liquid to Bootstrap 3.1.1 and tweaked styles (thanks to the Bootstrapify project)
- Fixed issue affecting the rendering of compare at / sale tags when selecting product options (thanks Gavin Walsh)
- Add additional checkout buttons when appropriate (thanks Gavin Walsh)

## V1.4.0 (January 14, 2014)

- Added checkout.css.liquid to both themes
- Minor bugfixes
- Minor style tweaks

## V1.3.0 (December 6, 2013)

- Updated Bootstrap 3 Theme to Bootstrap 3.0.3
- Add search.liquid Respond.js technique (see http://gavinballard.com/using-respond.js-with-shopify-redux/)
- Minor bugfix carousel not displaying in some instances

## V1.2.0 (November 25, 2013)

- Add side navigation bar and options
- Improvements to default navigation bar
- Sidebar and navigation bar use configurable link lists
- Simplify page contents
- Updates and improvements to theme settings

## V1.1.1 (November 19, 2013)

- Bugfixes
- Add navigation bar positioning to theme settings

## V1.1.0 (November 19, 2013)

- Add microdata for product pages
- Minor accessibility addition for screen readers

## v1.0.0 (November 8, 2013)
First release.

- Update Bootstrap 3 Theme to Bootstrap 3.0.2
- Slimmed down but finished Getting Started Guide
- Use minified CSS in both Bootstrap 2 and Bootstrap 3 Themes

## v0.9.7 (November 5, 2013)
Release candidate #1 for v1.0.0.

- Update Bootstrap 3 Theme to Bootstrap 3.0.1
- Improvements and bugfixes in Bootstrap 2 Theme
- Improvements and bugfixes in Bootstrap 3 Theme

## v0.9.4 (September 17, 2013)

 - Added lots of contact to Getting Started Guide
 - Update jQuery to v1.10.2

## v0.9.3 (August 12, 2013)

 - Added Bootstrap 3.0.0 Theme
 - Update Bootstrap 2 Theme to Bootstrap 2.3.2
 - Improved comment coverage in templates and snippets
 - Added 'product-list.liquid' snippet

## v0.9.0 (June 3, 2013)

- Added v1 of the Getting Started Guide.
- Added Open Graph tags to header.
- Moved snippets/tag.liquid into snippets/tag-list.liquid.
- Added thorough comments to snippets.
- Remove snippets/search.liquid (no longer used).
- Renamed js-product.js to js-bs4sf.js, and provide minified version.
- Use a sprite for payment method and social images instead of individual images.

## v0.8.0 (May 27, 2013)
First public beta release.

- Provides layouts, templates and snippets covering almost all of Shopify's Theme Guidelines.
- Responsive support in IE6-8 using Respond.js Shopify proxy technique.
- Retina-Ready.
