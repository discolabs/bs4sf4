Bootstrap for Shopify
=====================

Thanks for your support of Bootstrap for Shopify! I really appreciate it.

If you ever have any questions or complaints about this product, or just want
to get in touch, please don't hestitate! You can email me directly at
gavin@bootstrapforshopify.com. I'll try to get back to you as soon as possible.

This is the first "official" version of the framework. It's
been a long time coming, hampered by a vacation for myself (and a long wait for
the final release of Bootstrap 3). I consider both the Bootstrap 2 and Bootstrap
3 versions of the framework to be perfectly solid, and ready to be built on - 
if you find any bugs or quirks, please let me know!

As always, as soon as new updates are ready, I'll let you know and provide a link
to the updated packages so that you can stay in the loop.

Thanks again, and I hope that you find Bootstrap for Shopify useful!


- Gavin